management side是管理端部分
outbreak-0 是web端部分
outbreak-1 是小程序前端部分
outbreak-1-server是小程序后端部分

管理端，web后端，小程序后端都是由周于楷编写