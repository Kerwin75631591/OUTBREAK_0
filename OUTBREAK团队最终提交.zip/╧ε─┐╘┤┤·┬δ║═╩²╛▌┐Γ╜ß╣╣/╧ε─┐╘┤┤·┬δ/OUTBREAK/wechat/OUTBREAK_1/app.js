//app.js
App({
  globalData: {
    email: 'NULL'
  }
})